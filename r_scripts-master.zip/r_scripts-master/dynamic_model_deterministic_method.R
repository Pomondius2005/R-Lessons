
install.packages("TSA", dependencies=TRUE)
require(minpack.lm)
?nlsLM

require(HarmonicRegression)
?harmonic.regression

require(TSA)
?harmonic 

#http://www.loicdutrieux.com/bfastSpatial/
#install.packages("devtools", dependencies=TRUE)
require(bfast)
require(devtools)
#install_github('dutri001/bfastSpatial')
# load the package
require(bfastSpatial)
