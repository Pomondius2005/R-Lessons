structure(list(name = "phenoAmp", objs = structure(list(`package:wq` = structure(function (x, 
    ...) 
standardGeneric("phenoAmp"), generic = structure("phenoAmp", package = "wq"), package = "wq", group = list(), valueClass = character(0), signature = "x", default = quote(`\001NULL\001`), skeleton = quote((function (x, 
    ...) 
stop("invalid call in method dispatch to 'phenoAmp' (no default method)", 
    domain = NA))(x, ...)), class = structure("standardGeneric", package = "methods")), 
    structure(function (x, ...) 
    standardGeneric("phenoAmp"), generic = structure("phenoAmp", package = "wq"), package = "wq", group = list(), valueClass = character(0), signature = "x", default = quote(`\001NULL\001`), skeleton = quote((function (x, 
        ...) 
    stop("invalid call in method dispatch to 'phenoAmp' (no default method)", 
        domain = NA))(x, ...)), class = structure("standardGeneric", package = "methods"))), .Names = c("package:wq", 
"")), where = c("package:wq", "namespace:wq"), visible = c(TRUE, 
FALSE), dups = c(FALSE, TRUE)), .Names = c("name", "objs", "where", 
"visible", "dups"), class = "getAnywhere")
